var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_genai = require("@google/genai");
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
var leadsStorage = [];
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new import_genai.GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
}
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    agency: "Moockup Studio",
    website: "https://www.moockup.it",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Messaggio richiesto" });
    }
    const ai = getGeminiClient();
    const systemInstruction = `Sei l'assistente consulente virtuale di "Moockup Studio" (riferimento: www.moockup.it, email: moockupstudio@gmail.com), agenzia italiana di alto livello specializzata in:
1. Creazione e Sviluppo Siti Web & E-Commerce ad altissime prestazioni (PageSpeed 95+, UX studiata per la massima conversione, design moderno e mobile-first, Shopify, WooCommerce, Headless/Next.js/React).
2. SEO & Posizionamento su Google (SEO tecnica, ottimizzazione on-page/off-page, Keyword research strategica, local SEO e aumento traffico organico qualificato).
3. SEM & Google Ads (Specialisti in Google Ads: campagne Search mirate all'intento d'acquisto, Performance Max, Google Shopping, tracciamenti avanzati Server-Side GA4/GTM, abbattimento del Costo per Acquisizione / CPA e massimizzazione del ROAS).

Il tuo obiettivo \xE8:
- Rispondere in italiano in modo professionale, caloroso, chiaro, competente e orientato alla conversione.
- Spiegare come Moockup Studio aiuta aziende, professionisti ed e-commerce a vendere di pi\xF9 e ad acquisire lead qualificati.
- Offrire sempre valore pratico (es. spiegare perch\xE9 la velocit\xE0 del sito incide sulle conversioni, come scegliere le giuste parole chiave su Google Ads, o come richiedere l'Audit Gratuito).
- Se l'utente chiede un preventivo o tempi, dai stime orientative trasparenti e invitalo calorosamente a richiedere un Audit Gratuito tramite il form del sito o a lasciare la propria email/numero per una call strategica di 15 minuti senza impegno con il team di Moockup Studio (moockupstudio@gmail.com).
- Mantieni risposte snelle, formattate bene con elenchi puntati quando opportuno. Non essere prolisso.`;
    if (!ai) {
      let reply = "Grazie per aver contattato Moockup Studio! Siamo specializzati nella creazione di siti web moderni ad alta conversione, SEO su Google e campagne Google Ads. ";
      const lower = message.toLowerCase();
      if (lower.includes("prezzo") || lower.includes("costo") || lower.includes("preventivo")) {
        reply += "I nostri progetti sono su misura in base agli obiettivi aziendali: siti vetrina professionali da 1.200\u20AC, e-commerce completi da 2.500\u20AC e gestione campagne Google Ads con strategia ROI. Puoi anche usare il calcolatore interattivo sul sito o richiederci un audit gratuito!";
      } else if (lower.includes("google ads") || lower.includes("ads") || lower.includes("campagn")) {
        reply += "Siamo specialisti nella gestione di campagne Google Ads. Strutturiamo campagne Search, Shopping e Performance Max con tracciamento avanzato delle conversioni (GA4 e Server-Side) per massimizzare il ROAS e abbassare il CPA.";
      } else if (lower.includes("seo") || lower.includes("posizionamento") || lower.includes("google")) {
        reply += "Lavoriamo sulla SEO a 360\xB0: audit tecnico dei Core Web Vitals, architettura delle informazioni, keyword strategy focalizzata sull'intento di acquisto e link building di qualit\xE0 per portarti ai primi posti di Google.";
      } else {
        reply += "Come possiamo aiutarti oggi a far crescere il tuo business online? Puoi anche prenotare una call strategica o lasciarci il tuo contatto per essere ricontattato in 15 minuti.";
      }
      return res.json({ response: reply });
    }
    const formattedContents = [];
    for (const h of history.slice(-6)) {
      if (h.sender === "user") {
        formattedContents.push({ role: "user", parts: [{ text: h.text }] });
      } else if (h.sender === "bot") {
        formattedContents.push({ role: "model", parts: [{ text: h.text }] });
      }
    }
    formattedContents.push({ role: "user", parts: [{ text: message }] });
    const geminiResponse = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });
    const replyText = geminiResponse.text || "Grazie per il messaggio. Il nostro team di Moockup Studio ti risponder\xE0 al pi\xF9 presto.";
    return res.json({ response: replyText });
  } catch (error) {
    console.error("Chat error:", error);
    return res.status(500).json({
      error: "Errore durante la generazione della risposta",
      details: error?.message || "Errore sconosciuto"
    });
  }
});
app.post("/api/audit", (req, res) => {
  const { url, goal, email, name, phone, notes } = req.body;
  if (!url || !email) {
    return res.status(400).json({ error: "URL del sito ed email sono obbligatori" });
  }
  const lead = {
    id: `audit_${Date.now()}`,
    type: "audit",
    data: { url, goal, email, name, phone, notes },
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  leadsStorage.push(lead);
  console.log("Nuova richiesta Audit ricevuta per Moockup Studio:", lead);
  return res.json({
    success: true,
    message: "Richiesta di audit ricevuta con successo! Il team di Moockup Studio analizzer\xE0 il tuo sito e ti invier\xE0 il report entro 24 ore.",
    leadId: lead.id
  });
});
app.post("/api/contact", (req, res) => {
  const { name, email, phone, company, service, budget, message } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "Nome ed email sono obbligatori" });
  }
  const lead = {
    id: `contact_${Date.now()}`,
    type: "contact",
    data: { name, email, phone, company, service, budget, message },
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  leadsStorage.push(lead);
  console.log("Nuovo contatto ricevuto per Moockup Studio:", lead);
  return res.json({
    success: true,
    message: "Grazie per averci contattato! Un nostro specialista senior ti risponder\xE0 entro poche ore.",
    leadId: lead.id
  });
});
var CONTENT_FILE_PATH = import_path.default.join(process.cwd(), "site-content.json");
app.get("/api/content", (req, res) => {
  try {
    if (import_fs.default.existsSync(CONTENT_FILE_PATH)) {
      const data = import_fs.default.readFileSync(CONTENT_FILE_PATH, "utf-8");
      return res.json({ success: true, content: JSON.parse(data) });
    }
  } catch (err) {
    console.error("Error reading site-content.json:", err);
  }
  return res.json({ success: false, content: null });
});
app.post("/api/content", (req, res) => {
  try {
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: "Contenuto mancante" });
    }
    import_fs.default.writeFileSync(CONTENT_FILE_PATH, JSON.stringify(content, null, 2), "utf-8");
    console.log("Contenuti del sito salvati con successo per tutti gli utenti finali.");
    return res.json({ success: true, message: "Contenuto salvato per tutti gli utenti finali." });
  } catch (err) {
    console.error("Error writing site-content.json:", err);
    return res.status(500).json({ error: "Errore durante il salvataggio su server." });
  }
});
app.get("/api/leads", (req, res) => {
  res.json({
    count: leadsStorage.length,
    leads: leadsStorage
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Moockup Studio server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
